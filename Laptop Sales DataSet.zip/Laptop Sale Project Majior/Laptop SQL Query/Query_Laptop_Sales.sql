create database laptop_sales;
use laptop_sales;
show databases;

show tables;

# Rename Query
-- Renames the customer dimension table
RENAME TABLE dim_customer8 TO dim_customer;

-- Renames the date dimension table
RENAME TABLE dim_date7 TO dim_date;

-- Renames the employee dimension table
RENAME TABLE dim_employee6 TO dim_employee;

-- Renames the order dimension table
RENAME TABLE dim_order5 TO dim_order;

-- Renames the payment dimension table
RENAME TABLE dim_payment4 TO dim_payment;

-- Renames the product dimension table
RENAME TABLE dim_product3 TO dim_product;

-- Renames the store dimension table
RENAME TABLE dim_store2 TO dim_store;

-- Renames the sales fact table
RENAME TABLE fact_sale1 TO fact_sales;

# Check All Data Types
DESC dim_customer;
DESC dim_date;
DESC dim_employee;
DESC dim_order;
DESC dim_payment;
DESC dim_product;
DESC dim_store;
DESC fact_sales;

# --------------------------------------------------------{ Customer Query }---------------------------------------------------------

-- Display all records from customer table
SELECT * FROM dim_customer;

-- Modify data types and rename BOM column
ALTER TABLE dim_customer
CHANGE COLUMN `ï»¿Customer_ID` Customer_ID VARCHAR(20),
MODIFY Customer_Name VARCHAR(100),
MODIFY Gender VARCHAR(20),
MODIFY Age INT;

-- Add primary key on Customer_ID
ALTER TABLE dim_customer
ADD PRIMARY KEY (Customer_ID);

-- Check data types and primary key of customer table
DESC dim_customer;


# --------------------------------------------------------{ Date Query }---------------------------------------------------------

-- Display all records from date table
SELECT * FROM dim_date;

-- Disable safe update mode for the current MySQL session
SET SQL_SAFE_UPDATES = 0;

-- Convert Excel serial dates into MySQL date values
UPDATE dim_date
SET Full_Date = FROM_DAYS(Full_Date + 693594);

-- Change Full_Date from INT to DATE
ALTER TABLE dim_date
MODIFY Full_Date DATE;

-- Re-enable safe update mode
SET SQL_SAFE_UPDATES = 1;

-- Selects the laptop_sales database
USE laptop_sales;

-- Display all records from date table
SELECT * FROM dim_date;

-- Rename BOM column and modify data types
ALTER TABLE dim_date
CHANGE COLUMN `ï»¿Date_ID` Date_ID VARCHAR(20),
MODIFY Full_Date DATE,
MODIFY Day_Name VARCHAR(20),
MODIFY Week INT,
MODIFY Month INT,
MODIFY Month_Name VARCHAR(20),
MODIFY Quarter INT,
MODIFY Year INT,
MODIFY Financial_Year VARCHAR(20),
MODIFY Is_Weekend VARCHAR(10);

-- Add primary key on Date_ID
ALTER TABLE dim_date
ADD PRIMARY KEY (Date_ID);

-- Check data types and primary key
DESC dim_date;


# --------------------------------------------------------{ Employee Query }---------------------------------------------------------

-- Display all records from employee table
SELECT * FROM dim_employee;

-- Modify employee table data types
ALTER TABLE dim_employee
MODIFY Employee_ID VARCHAR(20) NOT NULL,
MODIFY Employee_Name VARCHAR(100),
MODIFY Gender VARCHAR(20),
MODIFY Department VARCHAR(100),
MODIFY Designation VARCHAR(100),
MODIFY Store_ID VARCHAR(20),
MODIFY Hire_Date INT,
MODIFY Contact_Number VARCHAR(20),
MODIFY Email VARCHAR(100),
MODIFY Performance_Rating DOUBLE;

-- Add primary key on Employee_ID
ALTER TABLE dim_employee
ADD PRIMARY KEY (Employee_ID);

-- Check employee table structure and primary key
DESC dim_employee;


# --------------------------------------------------------{ Order Query }---------------------------------------------------------

-- Select the laptop_sales database
USE laptop_sales;

-- Display all records from order table
SELECT * FROM dim_order;

-- Rename BOM column and modify data types
ALTER TABLE dim_order
CHANGE COLUMN `ï»¿Order_ID` Order_ID VARCHAR(20),
MODIFY Order_Date INT,
MODIFY Order_Status VARCHAR(50),
MODIFY Shipping_Method VARCHAR(50),
MODIFY Delivery_Date INT,
MODIFY Delivery_Status VARCHAR(50),
MODIFY Order_Priority VARCHAR(30),
MODIFY Payment_Status VARCHAR(50),
MODIFY Order_Type VARCHAR(50),
MODIFY Delivery_Time_Days INT,
MODIFY Courier_Partner VARCHAR(100),
MODIFY City VARCHAR(100),
MODIFY State VARCHAR(100),
MODIFY Country VARCHAR(100);

-- Add primary key on Order_ID
ALTER TABLE dim_order
ADD PRIMARY KEY (Order_ID);

-- Check data types and primary key
DESC dim_order;


# --------------------------------------------------------{ Payment Query }---------------------------------------------------------

-- Select the laptop_sales database
USE laptop_sales;

-- Display all records from payment table
SELECT * FROM dim_payment;

-- Rename BOM column and modify data types
ALTER TABLE dim_payment
CHANGE COLUMN `ï»¿Payment_ID` Payment_ID VARCHAR(20),
MODIFY Payment_Method VARCHAR(50),
MODIFY Payment_Status VARCHAR(50),
MODIFY Transaction_ID VARCHAR(50),
MODIFY Payment_Date INT,
MODIFY Bank_Name VARCHAR(100),
MODIFY Card_Type VARCHAR(50),
MODIFY EMI VARCHAR(20),
MODIFY Coupon_Code VARCHAR(50),
MODIFY Payment_Gateway VARCHAR(100);

-- Add primary key on Payment_ID
ALTER TABLE dim_payment
ADD PRIMARY KEY (Payment_ID);

-- Check data types and primary key
DESC dim_payment;


# --------------------------------------------------------{ Product Query }---------------------------------------------------------

-- Select the laptop_sales database
USE laptop_sales;

-- Display all records from product table
SELECT * FROM dim_product;

-- Rename BOM column and modify data types
ALTER TABLE dim_product
CHANGE COLUMN `ï»¿Product_ID` Product_ID VARCHAR(20),
MODIFY Brand VARCHAR(50),
MODIFY Processor VARCHAR(100),
MODIFY RAM INT,
MODIFY Storage INT,
MODIFY Graphics VARCHAR(100),
MODIFY OS VARCHAR(50),
MODIFY Screen_Size DOUBLE,
MODIFY Color VARCHAR(50),
MODIFY Warranty VARCHAR(50),
MODIFY Category VARCHAR(50);

-- Add primary key on Product_ID
ALTER TABLE dim_product
ADD PRIMARY KEY (Product_ID);

-- Check data types and primary key
DESC dim_product;


# --------------------------------------------------------{ Store Query }---------------------------------------------------------

-- Select the laptop_sales database
USE laptop_sales;

-- Display all records from store table
SELECT * FROM dim_store;

-- Rename BOM column and modify data types
ALTER TABLE dim_store
CHANGE COLUMN `ï»¿Store_ID` Store_ID VARCHAR(20),
MODIFY Store_Name VARCHAR(100),
MODIFY Store_Type VARCHAR(50),
MODIFY Branch_Code VARCHAR(30),
MODIFY City VARCHAR(100),
MODIFY State VARCHAR(100),
MODIFY Region VARCHAR(50),
MODIFY Manager_Name VARCHAR(100),
MODIFY Opening_Date VARCHAR(20);

-- Add primary key on Store_ID
ALTER TABLE dim_store
ADD PRIMARY KEY (Store_ID);

-- Check data types and primary key
DESC dim_store;


# --------------------------------------------------------{ Sales Query }---------------------------------------------------------

-- Select the laptop_sales database
USE laptop_sales;

-- Display all records from sales table
SELECT * FROM fact_sales;

-- Rename BOM column and modify data types
ALTER TABLE fact_sales
CHANGE COLUMN `ï»¿Sales_ID` Sales_ID VARCHAR(20),
MODIFY Order_ID VARCHAR(20),
MODIFY Date_ID VARCHAR(20),
MODIFY Product_ID VARCHAR(20),
MODIFY Customer_ID VARCHAR(20),
MODIFY Store_ID VARCHAR(20),
MODIFY Payment_ID VARCHAR(20),
MODIFY Employee_ID VARCHAR(20),
MODIFY Quantity DOUBLE,
MODIFY Unit_Price INT,
MODIFY Discount_Percentage VARCHAR(20),
MODIFY Discount_Amount INT,
MODIFY Tax_Amount INT,
MODIFY Total_Sales DOUBLE,
MODIFY Sales_Channel VARCHAR(50),
MODIFY Order_Status VARCHAR(50);

-- Add primary key on Sales_ID
ALTER TABLE fact_sales
ADD PRIMARY KEY (Sales_ID);

-- Check data types and primary key
DESC fact_sales;


# --------------------------------------------------------{ Primary Key Check }---------------------------------------------------------

-- Check all tables and their structures
DESC dim_customer;
DESC dim_date;
DESC dim_employee;
DESC dim_order;
DESC dim_payment;
DESC dim_product;
DESC dim_store;
DESC fact_sales;

# --------------------------------------------------------{ Customer Query }---------------------------------------------------------

-- Retrieve all records from customer table
SELECT * FROM dim_customer;

-- Disable safe update mode temporarily
SET SQL_SAFE_UPDATES = 0;

-- Convert Excel serial numbers into proper dates
UPDATE dim_customer
SET Registration_Date = FROM_DAYS(Registration_Date + 693594);

-- Change Registration_Date column from INT to DATE
ALTER TABLE dim_customer
MODIFY Registration_Date DATE;

-- Enable safe update mode again
SET SQL_SAFE_UPDATES = 1;

DESC dim_customer

# --------------------------------------------------------{ Date Query }---------------------------------------------------------

-- Retrieve all records from date table
SELECT * FROM dim_date;

# --------------------------------------------------------{ Employee Query }---------------------------------------------------------
-- Retrieve all records from employee table
SELECT * FROM dim_employee;

-- Disable safe update mode temporarily
SET SQL_SAFE_UPDATES = 0;

-- Convert Excel serial numbers into proper dates
UPDATE dim_employee
SET Hire_Date = FROM_DAYS(Hire_Date + 693594);

-- Change Hire_Date column from INT to DATE
ALTER TABLE dim_employee
MODIFY Hire_Date DATE;

-- Enable safe update mode again
SET SQL_SAFE_UPDATES = 1;

DESC dim_employee

# --------------------------------------------------------{ Order Query }---------------------------------------------------------
-- Retrieve all records from order table
SELECT * FROM dim_order;

-- Disable safe update mode temporarily
SET SQL_SAFE_UPDATES = 0;

-- Convert Excel serial numbers into proper dates
UPDATE dim_order
SET Delivery_Date = FROM_DAYS(Delivery_Date + 693594);

-- Change Delivery_Date column from INT to DATE
ALTER TABLE dim_order
MODIFY Delivery_Date DATE;

-- Enable safe update mode again
SET SQL_SAFE_UPDATES = 1;

DESC dim_order

# --------------------------------------------------------{ Payment Query }---------------------------------------------------------
-- Retrieve all records from payment table
SELECT * FROM dim_payment;

-- Disable safe update mode temporarily
SET SQL_SAFE_UPDATES = 0;

-- Convert Excel serial numbers into proper dates
UPDATE dim_payment
SET Payment_Date = FROM_DAYS(Payment_Date + 693594);

-- Change Payment_Date column from INT to DATE
ALTER TABLE dim_payment
MODIFY Payment_Date DATE;

-- Enable safe update mode again
SET SQL_SAFE_UPDATES = 1;

DESC dim_payment;

# --------------------------------------------------------{ Product Query }---------------------------------------------------------
-- Retrieve all records from product table
SELECT * FROM dim_product;


# --------------------------------------------------------{ Store Query }---------------------------------------------------------
-- Retrieve all records from store table
SELECT * FROM dim_store;

-- Temporarily disable Safe Update Mode
SET SQL_SAFE_UPDATES = 0;

-- Convert DD-MM-YYYY text into MySQL DATE value
UPDATE dim_store
SET Opening_Date = STR_TO_DATE(Opening_Date, '%d-%m-%Y');

-- Change Opening_Date datatype from VARCHAR to DATE
ALTER TABLE dim_store
MODIFY Opening_Date DATE;

-- Check the updated structure
DESC dim_store;

-- Check the converted dates
SELECT Store_ID, Store_Name, Opening_Date
FROM dim_store
LIMIT 10;

-- Enable Safe Update Mode again
SET SQL_SAFE_UPDATES = 1;


DESC dim_store;

# --------------------------------------------------------{ Sales Query }---------------------------------------------------------
-- Retrieve all records from sales table
SELECT * FROM fact_sales;

#-------------------------------------------------------------------------------------------------------------------------
#-------------------------------------------------------------------------------------------------------------------------

# --------------------------------------------------------{ Add this for KPI Query }---------------------------------------------------------
USE laptop_sales;
SHOW TABLES;


# ===========================
-- KPI 1 - Total Sales
# ===========================

SELECT
ROUND(SUM(Total_Sales), 2) AS Total_Sales
FROM fact_sales;


-- ===========================================
-- KPI 2 : Total Orders ID
-- ===========================================

SELECT
COUNT(DISTINCT Order_ID) AS Total_Orders_ID
FROM fact_sales;


-- ===========================================
-- KPI 3 : Total Quantity
-- ===========================================

SELECT
ROUND(SUM(Quantity), 2) AS Total_Quantity
FROM fact_sales;


-- ===========================================
-- KPI 4 : Order Value (AOV)
-- ===========================================

SELECT
ROUND(
SUM(Total_Sales) / COUNT(DISTINCT Order_ID),
2
) AS Order_Value_AOV
FROM fact_sales;


-- ===========================================
-- KPI 5 : Discount Rate (%)
-- ===========================================

SELECT
ROUND(
(
SUM(Discount_Amount) * 100.0
)
/ SUM(Total_Sales),
2
) AS Discount_Rate
FROM fact_sales;


/*=========================================================
  CHART 1: Sales by Brand (Column Chart)
=========================================================*/

SELECT
    p.Brand AS `Row Labels`,

    ROUND(
        SUM(f.Total_Sales),
        2
    ) AS `Total Sales`

FROM fact_sales f

JOIN dim_product p
    ON f.Product_ID = p.Product_ID

GROUP BY
    p.Brand

ORDER BY
    `Total Sales` DESC;
    

/*=========================================================
  CHART 2: Monthly Sales Trend (Line Chart)
=========================================================*/

SELECT
    d.Month,
    d.Month_Name AS `Row Labels`,

    ROUND(
        SUM(f.Total_Sales),
        2
    ) AS `Total Sales`

FROM fact_sales f

JOIN dim_date d
    ON f.Date_ID = d.Date_ID

GROUP BY
    d.Month,
    d.Month_Name

ORDER BY
    d.Month;
    
    
/*=========================================================
  CHART 3: Sales by Region (Bar Chart)
=========================================================*/

SELECT
    s.Region AS `Row Labels`,

    ROUND(
        SUM(f.Total_Sales),
        2
    ) AS `Total Sales`

FROM fact_sales f

JOIN dim_store s
    ON f.Store_ID = s.Store_ID

GROUP BY
    s.Region

ORDER BY
    `Total Sales` DESC;
    
    
/*=========================================================
  CHART 4: Sales by Sales Channel (Donut)
=========================================================*/

SELECT
    Sales_Channel AS `Row Labels`,

    ROUND(
        SUM(Total_Sales),
        2
    ) AS `Total Sales`

FROM fact_sales

GROUP BY Sales_Channel

ORDER BY `Total Sales` DESC;


